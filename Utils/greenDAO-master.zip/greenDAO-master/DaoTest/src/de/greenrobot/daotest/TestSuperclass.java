package de.greenrobot.daotest;

public class TestSuperclass {

}
